"""Flask web interface for GMAIS.

Features exposed by this interface:

* a manual **number-of-runs** input the operator submits to launch a run (each
  run is one scenario taken through all four factorial cells);
* **multi-provider** LLM selection (Claude / OpenAI / local), used round-robin
  with local fallback;
* a Validator **web-search toggle** that corroborates claims against verified
  government/institution sources, plus a textarea for **analyst-supplied
  sources**;
* a live **operational activity feed** over Server-Sent Events showing the
  behind-the-scenes work of every architectural component as it happens; and
* a results view with the **Ground Truth Knowledge Graph** for each scenario, a
  per-cell factorial comparison, and an **academic analytics** description of
  what each cell row means.

The deterministic ``mock`` backend is intentionally *not* offered as a user
option; it is reserved for tests/CI. Real runs use the selected providers and
fall back to a local model.
"""

from __future__ import annotations

import json
import math
import os
import threading
from dataclasses import asdict
from typing import Dict, List

from flask import Flask, Response, render_template, request

from .admiralty import grade_source
from .activity import ActivityRecorder
from .analytics_text import cell_analytics
from .config import CELLS, GMAISConfig, TIERS
from .llm import USER_PROVIDERS, build_multi_backend
from .metrics import ConfusionMatrix, compute_security_tax
from .orchestrator import GMAISOrchestrator
from .scenarios import generate_corpus
from .web_search import VerifiedSourceSearch, parse_user_sources

# Templates live in the repository-root templates/ directory.
_TEMPLATE_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "templates")


def _sample_scenarios(seed: int, n_runs: int) -> List:
    """Generate ``n_runs`` scenarios, interleaved across complexity tiers."""
    per_tier = max(1, math.ceil(n_runs / len(TIERS)))
    corpus = generate_corpus(seed, per_tier)
    # Interleave low/medium/high so small run counts still span tiers.
    by_tier: Dict[str, List] = {t: [] for t in TIERS}
    for s in corpus:
        by_tier[s.tier].append(s)
    interleaved: List = []
    for i in range(per_tier):
        for t in TIERS:
            if i < len(by_tier[t]):
                interleaved.append(by_tier[t][i])
    return interleaved[:n_runs]


def _gtkg_claims(scenario) -> List[dict]:
    """Build the GTKG claim rows (with Admiralty grades) for display."""
    rows = []
    for c in scenario.claims:
        grade = grade_source(c.source)
        rows.append({
            "cid": c.cid, "text": c.text,
            "provenance": c.source.get("provenance", "unknown"),
            "corroboration": c.source.get("corroboration", 0),
            "admiralty": grade.code, "confidence": grade.confidence,
            "is_true": c.is_true, "is_injected": c.is_injected, "supports": c.supports,
        })
    return rows


def _build_results(config: GMAISConfig, n_runs: int, providers: List[str],
                   sources_raw: str, use_search: bool, recorder: ActivityRecorder) -> dict:
    """Execute the runs end-to-end, emitting activity, and assemble results."""

    emit = recorder.emit
    emit("init", f"Starting {n_runs} run(s) across {len(CELLS)} factorial cells")

    # 1. Construct the round-robin multi-provider backend (logs availability).
    backend = build_multi_backend(providers, seed=config.seed, activity=emit)
    emit("init", f"Providers active: {', '.join(backend.available_providers)}", status="done",
         providers=backend.available_providers)

    # 2. Build the Validator's verified-source search client (+ analyst sources).
    user_hits = parse_user_sources(sources_raw)
    web_search = None
    if use_search or user_hits:
        web_search = VerifiedSourceSearch(user_hits)
        emit("init", f"Validator web search enabled - {web_search.n_verified_user_sources} "
             f"verified analyst source(s) supplied", status="done")

    orchestrator = GMAISOrchestrator(backend, config)
    scenarios = _sample_scenarios(config.seed, n_runs)

    # 3. Run each scenario through all four cells, collecting observations.
    per_scenario: List[dict] = []
    observations: List[dict] = []          # for Security-Tax z-scoring
    cell_acc: Dict[str, ConfusionMatrix] = {c.name: ConfusionMatrix() for c in CELLS}
    cell_hits: Dict[str, List[int]] = {c.name: [] for c in CELLS}
    cell_lat: Dict[str, List[float]] = {c.name: [] for c in CELLS}
    cell_tok: Dict[str, List[int]] = {c.name: [] for c in CELLS}
    cell_bias: Dict[str, List[int]] = {c.name: [] for c in CELLS}

    for scenario in scenarios:
        emit("run", f"=== Run for scenario {scenario.sid} ({scenario.tier} tier) ===")
        rows = []
        results_by_cell = {}
        for cell in CELLS:
            res = orchestrator.analyze(scenario, cell, activity=emit, web_search=web_search)
            results_by_cell[cell.name] = res
            gov = asdict(res.governance) if res.governance else None
            if gov:
                gov.pop("redacted_messages", None)
            rows.append({
                "cell": cell.name, "validation": cell.validation, "governance": cell.governance,
                "predicted": res.predicted_hypothesis, "correct": res.correct,
                "detected": res.detected_injection_cids, "confidence": res.confidence,
                "latency_ms": res.latency_ms, "tokens": res.tokens,
                "audit_intact": None if gov is None else gov["audit_intact"],
                "events": None if gov is None else gov["events_total"],
                "redacted": None if gov is None else gov["events_redacted"],
                "peer_events": None if gov is None else gov["peer_events"],
                "entities_redacted": res.entities_redacted,
                "bias_exposure": res.peer_bias_exposure,
                "corroboration": res.verified_corroboration,
            })
            observations.append({"scenario_id": scenario.sid, "tier": scenario.tier,
                                 "cell": cell.name, "latency_ms": res.latency_ms,
                                 "tokens": res.tokens})
            # Accumulate aggregate metrics.
            for cid in (c.cid for c in scenario.claims):
                cell_acc[cell.name].add(cid in set(res.detected_injection_cids),
                                        cid in set(res.gold_injection_cids))
            cell_hits[cell.name].append(int(res.correct))
            cell_lat[cell.name].append(res.latency_ms)
            cell_tok[cell.name].append(res.tokens)
            cell_bias[cell.name].append(res.peer_bias_exposure)

        # Per-scenario differentials versus that scenario's Baseline.
        base = next(r for r in rows if r["cell"] == "Baseline")
        for r in rows:
            r["delta_latency"] = round(r["latency_ms"] - base["latency_ms"], 1)
            r["delta_tokens"] = r["tokens"] - base["tokens"]
            r["analytics"] = cell_analytics(r["cell"], r, base)
        per_scenario.append({
            "sid": scenario.sid, "tier": scenario.tier,
            "gold": scenario.gold_hypothesis, "injected": scenario.injected_cids,
            "entities": scenario.entities, "hypotheses": scenario.hypotheses,
            "text": scenario.text, "gtkg_claims": _gtkg_claims(scenario), "rows": rows,
        })

    # 4. Aggregate per-cell summary across all runs (+ Security Tax).
    emit("analyse", "Computing aggregate metrics and Security-Tax distribution")
    st_results = compute_security_tax(
        observations, alpha=config.st_alpha, beta=config.st_beta,
        band_low=config.st_band_low, band_high=config.st_band_high,
    )
    st_by_cell: Dict[str, List[float]] = {c.name: [] for c in CELLS}
    for st in st_results:
        st_by_cell[st.cell].append(st.security_tax)

    def _mean(xs):
        return round(sum(xs) / len(xs), 3) if xs else 0.0

    base_lat = _mean(cell_lat["Baseline"])
    base_tok = _mean(cell_tok["Baseline"])
    aggregate = []
    for c in CELLS:
        name = c.name
        agg = {
            "cell": name, "validation": c.validation, "governance": c.governance,
            "n": len(cell_hits[name]),
            "correct": _mean(cell_hits[name]),                 # accuracy rate
            "detection_f1": round(cell_acc[name].f1, 3),
            "latency_ms": _mean(cell_lat[name]),
            "tokens": _mean(cell_tok[name]),
            "delta_latency": round(_mean(cell_lat[name]) - base_lat, 1),
            "delta_tokens": round(_mean(cell_tok[name]) - base_tok, 1),
            "bias_exposure": _mean(cell_bias[name]),
            "security_tax": _mean(st_by_cell[name]),
        }
        agg["analytics"] = cell_analytics(name, agg, {"delta_latency": 0, "delta_tokens": 0})
        aggregate.append(agg)

    emit("done", "Run complete - rendering results", status="done")

    # 5. Render the results fragment (within app context, in the worker thread).
    html = render_template("_results.html", aggregate=aggregate, per_scenario=per_scenario,
                           n_runs=n_runs, providers=backend.available_providers,
                           web_search=web_search is not None)
    return {"html": html}


def create_app(config: GMAISConfig | None = None) -> Flask:
    """Application factory."""
    config = config or GMAISConfig()
    app = Flask(__name__, template_folder=_TEMPLATE_DIR)

    @app.route("/")
    def index():
        # Render the control page; the run itself is launched via SSE.
        return render_template("gmais.html", providers=USER_PROVIDERS)

    @app.route("/stream")
    def stream():
        # Parse the operator's run configuration from the query string.
        try:
            n_runs = max(1, min(60, int(request.args.get("runs", "3"))))
        except ValueError:
            n_runs = 3
        providers = [p for p in request.args.get("providers", "local").split(",") if p in USER_PROVIDERS]
        if not providers:
            providers = ["local"]
        sources_raw = request.args.get("sources", "")
        use_search = request.args.get("websearch", "0") == "1"

        recorder = ActivityRecorder()

        def run_pipeline():
            # Execute inside an app context so render_template works off-thread.
            with app.app_context():
                try:
                    result = _build_results(config, n_runs, providers, sources_raw,
                                            use_search, recorder)
                    recorder.finish(result)
                except Exception as exc:  # surface failures to the feed
                    recorder.fail(f"Run failed: {exc}")

        threading.Thread(target=run_pipeline, daemon=True).start()

        def generate():
            # SSE preamble; then drain the recorder until the sentinel.
            yield "retry: 3000\n\n"
            for item in recorder.stream():
                if isinstance(item, tuple) and item[0] == "result":
                    yield f"event: result\ndata: {json.dumps(item[1])}\n\n"
                else:
                    yield f"event: activity\ndata: {json.dumps(item.to_dict())}\n\n"
            yield "event: end\ndata: {}\n\n"

        return Response(generate(), mimetype="text/event-stream",
                        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

    return app


app = create_app(GMAISConfig(scenarios_per_tier=5))

if __name__ == "__main__":  # pragma: no cover
    # threaded=True so the SSE stream and the worker thread run concurrently.
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), threaded=True)
