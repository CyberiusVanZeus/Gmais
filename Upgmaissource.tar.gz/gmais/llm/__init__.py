"""LLM backend package.

Exposes a factory for single-provider backends and a helper for the
multi-provider round-robin router used by the web interface.

Provider names:
* ``claude`` - Anthropic Claude (light Haiku model by default)
* ``openai`` - hosted OpenAI (light gpt-4o-mini by default)
* ``local``  - any local OpenAI-compatible server (llama.cpp / LM Studio / Ollama)
* ``mock``   - deterministic offline stub, for tests/CI only
"""

from __future__ import annotations

from typing import List, Optional

from .base import LLMBackend, LLMResponse, estimate_tokens
from .mock import DeterministicMockBackend
from .multi import MultiProviderBackend

#: Providers a user may legitimately select from the web interface.
USER_PROVIDERS = ("claude", "openai", "local")


def build_backend(name: str = "mock", *, seed: int = 0, model: str = "gmais-mock") -> LLMBackend:
    """Factory: construct a single backend by provider name."""

    name = name.lower()
    if name == "mock":
        return DeterministicMockBackend(seed=seed, model=model)
    if name == "claude":
        from .anthropic_backend import AnthropicBackend

        return AnthropicBackend()
    if name in ("openai", "local", "openai_compat"):
        from .openai_compat import OpenAICompatBackend

        provider = "local" if name == "local" else "openai"
        return OpenAICompatBackend(provider=provider)
    raise ValueError(f"Unknown LLM backend: {name!r}")


def build_multi_backend(
    providers: List[str], *, seed: int = 0, activity=None
) -> MultiProviderBackend:
    """Construct a round-robin multi-provider backend with local fallback."""

    return MultiProviderBackend(providers, seed=seed, activity=activity)


__all__ = [
    "LLMBackend",
    "LLMResponse",
    "estimate_tokens",
    "DeterministicMockBackend",
    "MultiProviderBackend",
    "build_backend",
    "build_multi_backend",
    "USER_PROVIDERS",
]
