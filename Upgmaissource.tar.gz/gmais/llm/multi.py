"""Multi-provider routing: round-robin with local fallback.

The web interface lets the operator select any combination of providers
(Claude / OpenAI / local) to run *simultaneously*. Per the chosen policy, calls
are distributed **round-robin** across the selected providers: call 1 -> first
provider, call 2 -> second, and so on, wrapping around. This produces a genuine
heterogeneous run while keeping per-provider load balanced.

If a provider fails or is unconfigured at call time, routing **falls back to the
local model** so a run never aborts mid-pipeline. A deterministic offline mock
is used only as a last-resort safety net for tests/CI (never surfaced as a user
option), and only when explicitly allowed via ``GMAIS_ALLOW_MOCK``.
"""

from __future__ import annotations

import itertools
import os
from typing import Callable, List, Optional

from .base import LLMBackend, LLMResponse

# Type of the optional activity callback: (stage, message, **data) -> None.
ActivityFn = Callable[..., None]


class MultiProviderBackend(LLMBackend):
    """Round-robins across selected providers, falling back to local."""

    name = "multi"

    def __init__(
        self,
        providers: List[str],
        *,
        seed: int = 0,
        activity: Optional[ActivityFn] = None,
    ) -> None:
        if not providers:
            providers = ["local"]
        self.requested = list(providers)
        self.seed = seed
        self._activity = activity
        # Lazily construct each backend; keep only those that initialise.
        self._backends: dict[str, LLMBackend] = {}
        self._available: List[str] = []
        for p in self.requested:
            backend = self._try_build(p)
            if backend is not None:
                self._backends[p] = backend
                self._available.append(p)
        # Ensure a local fallback backend exists if not already present.
        self._fallback = self._backends.get("local") or self._try_build("local")
        if self._fallback is None and os.getenv("GMAIS_ALLOW_MOCK"):
            # Last-resort safety net for offline tests/CI only.
            self._fallback = self._try_build("mock")
        if not self._available and self._fallback is not None:
            self._available = ["local" if "local" in self._backends else "fallback"]
            self._backends.setdefault("fallback", self._fallback)
        if not self._available:
            raise RuntimeError(
                "No LLM provider could be initialised. Configure at least one of "
                "ANTHROPIC_API_KEY / OPENAI_API_KEY / a local OpenAI-compatible "
                "server (GMAIS_LOCAL_BASE_URL)."
            )
        # Infinite round-robin cycle over the available provider names.
        self._cycle = itertools.cycle(self._available)

    def _try_build(self, provider: str) -> Optional[LLMBackend]:
        """Attempt to construct a single provider backend; None on failure."""
        try:
            if provider == "claude":
                from .anthropic_backend import AnthropicBackend

                return AnthropicBackend()
            if provider in ("openai", "local"):
                from .openai_compat import OpenAICompatBackend

                return OpenAICompatBackend(provider=provider)
            if provider == "mock":
                from .mock import DeterministicMockBackend

                return DeterministicMockBackend(seed=self.seed)
        except Exception as exc:  # provider unavailable / missing key
            if self._activity:
                self._activity("provider", f"{provider} unavailable ({exc}); skipping",
                               status="warn")
        return None

    @property
    def available_providers(self) -> List[str]:
        return list(self._available)

    def generate(
        self,
        prompt: str,
        *,
        temperature: float,
        max_tokens: int = 512,
        role: str = "worker",
    ) -> LLMResponse:
        # Pick the next provider in the round-robin rotation.
        provider = next(self._cycle)
        backend = self._backends.get(provider, self._fallback)
        try:
            resp = backend.generate(
                prompt, temperature=temperature, max_tokens=max_tokens, role=role
            )
            if not resp.provider:
                resp.provider = provider
            return resp
        except Exception as exc:
            # Fall back to the local model on any runtime failure.
            if self._activity:
                self._activity("provider", f"{provider} call failed ({exc}); "
                               f"falling back to local", status="warn")
            if self._fallback is None:
                raise
            resp = self._fallback.generate(
                prompt, temperature=temperature, max_tokens=max_tokens, role=role
            )
            resp.provider = resp.provider or "local"
            return resp
