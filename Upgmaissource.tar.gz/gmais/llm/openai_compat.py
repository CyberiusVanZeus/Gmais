"""OpenAI-compatible backend for hosted OpenAI *and* local models.

A single implementation serves two providers because both speak the OpenAI Chat
Completions API:

* ``openai`` - the hosted OpenAI API. Defaults to a *light* model (gpt-4o-mini)
  to honour the resource-constrained brief; override with ``GMAIS_OPENAI_MODEL``.
  Auth via ``OPENAI_API_KEY``.
* ``local``  - any local server exposing the same API: llama.cpp ``server``,
  LM Studio, or Ollama's OpenAI endpoint, typically hosting a quantised GGUF
  Q4_K_M model. Base URL via ``GMAIS_LOCAL_BASE_URL`` (default
  ``http://localhost:8080/v1``); model via ``GMAIS_LOCAL_MODEL``.

The ``openai`` SDK is imported lazily so it stays an optional dependency.
"""

from __future__ import annotations

import os
import time

from .base import LLMBackend, LLMResponse, estimate_tokens

# Light hosted OpenAI default; cheap and fast, in keeping with the MVA brief.
DEFAULT_OPENAI_MODEL = "gpt-4o-mini"
DEFAULT_LOCAL_MODEL = "local-model"
DEFAULT_LOCAL_BASE_URL = "http://localhost:8080/v1"


class OpenAICompatBackend(LLMBackend):
    """Backend that calls an OpenAI-compatible chat-completions endpoint."""

    def __init__(self, *, provider: str = "openai", model: str | None = None) -> None:
        # Lazy import keeps openai optional.
        try:
            from openai import OpenAI
        except ImportError as exc:  # pragma: no cover - optional dependency
            raise RuntimeError(
                "The 'openai' package is required for the OpenAI/local backend. "
                "Install it with `pip install openai`."
            ) from exc

        self.name = provider  # "openai" or "local"
        if provider == "local":
            # Local servers usually need no real key; base URL points at the host.
            base_url = os.getenv("GMAIS_LOCAL_BASE_URL", DEFAULT_LOCAL_BASE_URL)
            api_key = os.getenv("GMAIS_LOCAL_API_KEY", "not-needed")
            self.model = model or os.getenv("GMAIS_LOCAL_MODEL", DEFAULT_LOCAL_MODEL)
        else:
            # Hosted OpenAI: real key required; default base URL from the SDK.
            base_url = os.getenv("GMAIS_OPENAI_BASE_URL")  # None -> SDK default
            api_key = os.getenv("OPENAI_API_KEY")
            if not api_key:
                # Surfaced so multi-provider routing can fall back to local.
                raise RuntimeError("OPENAI_API_KEY is not set.")
            self.model = model or os.getenv("GMAIS_OPENAI_MODEL", DEFAULT_OPENAI_MODEL)

        # base_url=None lets the SDK use its built-in default for hosted OpenAI.
        self._client = OpenAI(base_url=base_url, api_key=api_key) if base_url else OpenAI(api_key=api_key)

    def generate(
        self,
        prompt: str,
        *,
        temperature: float,
        max_tokens: int = 512,
        role: str = "worker",
    ) -> LLMResponse:
        # Time the round trip for real latency telemetry.
        start = time.perf_counter()
        resp = self._client.chat.completions.create(
            model=self.model,
            temperature=temperature,
            max_tokens=max_tokens,
            messages=[{"role": "user", "content": prompt}],
        )
        latency_ms = (time.perf_counter() - start) * 1000.0

        text = (resp.choices[0].message.content or "").strip()
        usage = getattr(resp, "usage", None)
        if usage is not None:
            prompt_tokens = usage.prompt_tokens
            completion_tokens = usage.completion_tokens
        else:  # pragma: no cover - some servers omit usage
            prompt_tokens = estimate_tokens(prompt)
            completion_tokens = estimate_tokens(text)

        return LLMResponse(
            text=text,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            latency_ms=round(latency_ms, 3),
            model=self.model,
            role=role,
            provider=self.name,
        )
